"""Moonshine agent runtime internals."""

