"""Moonshine CLI package."""

