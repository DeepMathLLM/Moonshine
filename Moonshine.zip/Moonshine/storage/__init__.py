"""Moonshine storage package."""

